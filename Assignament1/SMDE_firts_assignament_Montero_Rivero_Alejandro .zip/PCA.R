###########################################################
# Clear all environment variables
###########################################################

# Remove previous objects
rm(list=ls(all=TRUE))

######################################
# Load libraries 
######################################

library(Rcmdr)
library(FactoMineR)

######################################
# Load data 
######################################

data(decathlon, package="FactoMineR")
names(decathlon) <- make.names(names(decathlon))          
                               
######################################
# PCA
######################################
jpeg('plot.jpg')

decathlon.PCA<-decathlon[, c("X100m", "Long.jump", "Shot.put", "High.jump", 
                             "X400m", "X110m.hurdle", "Discus", "Pole.vault", "Javeline", "X1500m", 
                             "Rank", "Points")]

res<-PCA(decathlon.PCA , scale.unit=TRUE, ncp=5, graph = FALSE)

res.hcpc<-HCPC(res ,nb.clust=-1,consol=FALSE,min=3,max=10,graph=TRUE)

plot.PCA(res, axes=c(1, 2), choix="ind", habillage="none", col.ind="black", 
         col.ind.sup="blue", col.quali="magenta", label=c("ind", "ind.sup", "quali"),
         new.plot=TRUE)

plot.PCA(res, axes=c(1, 2), choix="var", new.plot=TRUE, col.var="black", 
         col.quanti.sup="blue", label=c("var", "quanti.sup"), lim.cos2.var=0)

dev.off()
summary(res, nb.dec = 3, nbelements=10, nbind = 10, ncp = 3, file="")


#-------------------------------------
# Variable Contribution
#-------------------------------------

res$var$contrib[,1:2]


remove(decathlon.PCA)

